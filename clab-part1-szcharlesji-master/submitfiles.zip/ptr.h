#pragma once

void incr(int *ptr);
void initialize_ptr(void **ptr);
void swap_int(int *x, int *y);
