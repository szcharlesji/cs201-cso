#pragma once

int array_sum(int *arr, int n);
void array_cpy(int *dst, int *src, int n);
void bubble_sort(int *arr, int n);
int big_to_little_endian(char *arr);
